#include <CANSAME5x.h>
#include <Arduino.h>
#include <Wire.h>

// Define named constants for CAN IDs and data formats
enum CanId
{
  CAN_ID_ACCEL = 0x100,
  CAN_ID_GYRO = 0x101,
  CAN_ID_MAG = 0x102,
  CAN_ID_CONFIG = 0x0E5
};

#define ACCEL_RESOLUTION 0.001f
#define GYRO_RESOLUTION 0.1f
#define MAG_RESOLUTION 0.01f

class CanMessage
{
public:
  uint8_t id;
  uint8_t len;
  uint8_t data[8];

  // Add bounds checking for data access
  uint8_t getData(uint8_t index)
  {
    if (index < len)
    {
      return data[index];
    }
    else
    {
      return 0; // or some error value
    }
  }
};

CANSAME5x CAN; // Create a CAN object
void parseData(CanMessage);

void setup()
{
  Serial.begin(9600); // Initialize serial communication

  // Initialize the CAN bus
  CAN.begin(500000); // Initialize the CAN bus with a baud rate of 500 Kbps

  // Configure the IMU with default settings
  CanMessage txMsg;
  txMsg.id = CAN_ID_CONFIG;
  txMsg.len = 8;
  uint8_t defaultSettings[] = {
      0x01, // Command byte (0x01 for default settings)
      0x02, // Accelerometer range (0x02 for ±12G)
      0x01, // Gyroscope range (0x01 for ±250 °/s)
      0x02, // Accelerometer 3dB cutoff frequency (0x02 for 40 Hz)
      0x01, // Gyroscope 3dB cutoff frequency (0x01 for 32 Hz)
      0x00, // Reserved byte
      0x00, // Reserved byte
      0x00  // Reserved byte
  };
  for (int i = 0; i < 8; i++)
  {
    txMsg.data[i] = defaultSettings[i];
  }
  CAN.write(txMsg.data[0]); // Pass txMsg object directly to write method
  delay(100);       // Wait for the IMU to reset and apply the new configuration

  // Reprogram CAN ID to set sensor sensitivity
  uint8_t reprogramData[] = {
      0x01, // Command byte (0x01 for reprogramming)
      0x01, // Accelerometer range (0x01 for ±6G)
      0xAA, // Gyroscope range (0xAA for ±250 °/s)
      0x01, // Baud rate (0x01 for 500 Kbps)
      0x06, // CAN HI byte (0x06 for base ID 0x635)
      0x35, // CAN LO byte (0x35 for base ID 0x635)
      0x00, // Reserved byte
      0x00  // Reserved byte
  };
  txMsg.id = CAN_ID_CONFIG;
  txMsg.len = 8;
  for (int i = 0; i < 8; i++)
  {
    txMsg.data[i] = reprogramData[i];
  }
  CAN.write(txMsg.data, txMsg.len); // Pass txMsg object directly to write method
  delay(400);       // Wait for the IMU to reset and apply the new configuration
}

void loop()
{
  // Receive CAN messages
  CanMessage rxMsg;
  if(CAN.available())
  {
    rxMsg.id = CAN.packetId();
    rxMsg.data[0] = CAN.read();
    rxMsg.data[1] = CAN.read();
    rxMsg.data[2] = CAN.read();
    rxMsg.data[3] = CAN.read();
    rxMsg.data[4] = CAN.read();
    rxMsg.data[5] = CAN.read();
    rxMsg.data[6] = CAN.read();
    rxMsg.data[7] = CAN.read();
    parseData(rxMsg);
  }
}

void parseData(CanMessage rxMsg)
{
  if (rxMsg.id == CAN_ID_ACCEL)
    {
      // Parse acceleration data
      float ax = (rxMsg.getData(0) << 8 | rxMsg.getData(1)) * ACCEL_RESOLUTION;
      float ay = (rxMsg.getData(2) << 8 | rxMsg.getData(3)) * ACCEL_RESOLUTION;
      float az = (rxMsg.getData(4) << 8 | rxMsg.getData(5)) * ACCEL_RESOLUTION;
      Serial.print("Acceleration: ");
      Serial.print(ax);
      Serial.print(", ");
      Serial.print(ay);
      Serial.print(", ");
      Serial.println(az);
    }
    else if (rxMsg.id == CAN_ID_GYRO)
    {
      // Parse gyroscope data
      float gx = (rxMsg.getData(0) << 8 | rxMsg.getData(1)) * GYRO_RESOLUTION;
      float gy = (rxMsg.getData(2) << 8 | rxMsg.getData(3)) * GYRO_RESOLUTION;
      float gz = (rxMsg.getData(4) << 8 | rxMsg.getData(5)) * GYRO_RESOLUTION;
      Serial.print("Gyroscope: ");
      Serial.print(gx);
      Serial.print(", ");
      Serial.print(gy);
      Serial.print(", ");
      Serial.println(gz);
    }
    else if (rxMsg.id == CAN_ID_MAG)
    {
      // Parse magnetometer data
      float mx = (rxMsg.getData(0) << 8 | rxMsg.getData(1)) * MAG_RESOLUTION;
      float my = (rxMsg.getData(2) << 8 | rxMsg.getData(3)) * MAG_RESOLUTION;
      float mz = (rxMsg.getData(4) << 8 | rxMsg.getData(5)) * MAG_RESOLUTION;
      Serial.print("Magnetometer: ");
      Serial.print(mx);
      Serial.print(", ");
      Serial.print(my);
      Serial.print(", ");
      Serial.println(mz);
    }
}